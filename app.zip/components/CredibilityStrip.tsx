"use client";

import { motion } from "motion/react";

const stats = [
  {
    value: "1.5+",
    label: "Years Experience",
  },
  {
    value: "01",
    label: "Commercial Product UI",
  },
  {
    value: "Full Stack",
    label: "Flutter + Backend",
  },
  {
    value: "Design + Dev",
    label: "Figma to Code",
  },
];

export default function CredibilityStrip() {
  return (
    <section className="px-6 py-10">
      <div className="mx-auto grid max-w-7xl gap-4 rounded-[2rem] border border-white/10 bg-white/[0.03] p-4 md:grid-cols-4">
        {stats.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, delay: index * 0.08 }}
            className="rounded-[1.5rem] border border-white/10 bg-black/20 p-6 text-center"
          >
            <h3 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">
              {item.value}
            </h3>
            <p className="mt-3 text-sm uppercase tracking-[0.25em] text-white/40">
              {item.label}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}