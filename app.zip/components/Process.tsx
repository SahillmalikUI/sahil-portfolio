"use client";

import { motion } from "motion/react";

const processSteps = [
  {
    step: "01",
    title: "Understand",
    text: "I first understand the product goal, users, flows, and what the interface actually needs to solve.",
  },
  {
    step: "02",
    title: "Design",
    text: "I create clean layouts, visual direction, components, and user flows in Figma before jumping into code.",
  },
  {
    step: "03",
    title: "Build",
    text: "I turn the design into responsive, smooth, production-ready interfaces using modern frontend tools.",
  },
  {
    step: "04",
    title: "Connect",
    text: "I integrate APIs, authentication, backend logic, databases, and real product data where needed.",
  },
  {
    step: "05",
    title: "Polish",
    text: "I refine spacing, motion, responsiveness, performance, and tiny UI details until the product feels premium.",
  },
];

export default function Process() {
  return (
    <section className="relative px-6 py-28">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
            Process
          </p>

          <h2 className="max-w-4xl text-4xl font-semibold tracking-tight md:text-6xl">
            I don’t just make screens. I shape the full experience.
          </h2>

          <p className="mt-6 max-w-2xl text-base leading-8 text-white/50">
            My workflow connects product thinking, design taste, development,
            backend integration, and final polish.
          </p>
        </motion.div>

        <div className="grid gap-5 md:grid-cols-5">
          {processSteps.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 45 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-120px" }}
              transition={{ duration: 0.7, delay: index * 0.1 }}
              className="group relative min-h-[280px] overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 transition duration-500 hover:-translate-y-1 hover:border-cyan-300/40 hover:bg-white/[0.06]"
            >
              <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-cyan-300/0 blur-[70px] transition duration-500 group-hover:bg-cyan-300/20" />

              <div className="relative z-10">
                <p className="text-sm text-cyan-300/60">{item.step}</p>

                <h3 className="mt-8 text-2xl font-semibold tracking-tight">
                  {item.title}
                </h3>

                <p className="mt-5 text-sm leading-7 text-white/50">
                  {item.text}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}