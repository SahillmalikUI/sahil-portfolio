"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";

export default function ScrollProgress() {
  const progressRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const updateProgress = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.body.scrollHeight - window.innerHeight;
      const progress = docHeight > 0 ? scrollTop / docHeight : 0;

      gsap.to(progressRef.current, {
        scaleX: progress,
        duration: 0.2,
        ease: "power2.out",
      });
    };

    window.addEventListener("scroll", updateProgress);
    updateProgress();

    return () => window.removeEventListener("scroll", updateProgress);
  }, []);

  return (
    <div className="fixed left-0 top-0 z-[100] h-[2px] w-full bg-white/5">
      <div
        ref={progressRef}
        className="h-full origin-left scale-x-0 bg-cyan-300"
      />
    </div>
  );
}