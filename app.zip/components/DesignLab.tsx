"use client";

import { motion } from "motion/react";

const designItems = [
  {
    title: "Healthcare Dashboard Concepts",
    category: "Product UI",
    description:
      "Clean dashboard layouts for health data, vitals, patient flows, and real-time monitoring interfaces.",
  },
  {
    title: "Mobile App Interfaces",
    category: "App Design",
    description:
      "Modern mobile screens focused on clarity, smooth user flows, and premium visual hierarchy.",
  },
  {
    title: "Landing Page Experiments",
    category: "Web Design",
    description:
      "Hero sections, SaaS-style pages, animated sections, and conversion-focused layouts.",
  },
  {
    title: "Brand & Visual Systems",
    category: "Identity",
    description:
      "Logo direction, color systems, interface components, and visual consistency experiments.",
  },
];

export default function DesignLab() {
  return (
    <section id="design-lab" className="relative px-6 py-28">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
            Design Lab
          </p>

          <h2 className="max-w-4xl text-4xl font-semibold tracking-tight md:text-6xl">
            Visual experiments that show my eye for product design.
          </h2>

          <p className="mt-6 max-w-2xl text-base leading-8 text-white/50">
            A space for interface explorations, dashboard concepts, mobile app
            designs, landing pages, and brand visuals created through Figma and
            frontend implementation.
          </p>
        </motion.div>

        <div className="grid gap-5 md:grid-cols-2">
          {designItems.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-120px" }}
              transition={{ duration: 0.7, delay: index * 0.12 }}
              className="group relative min-h-[300px] overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.03] p-7 transition duration-500 hover:border-cyan-300/40 hover:bg-white/[0.06]"
            >
              <div className="absolute inset-0 opacity-0 transition duration-500 group-hover:opacity-100">
                <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-cyan-400/15 blur-[90px]" />
              </div>

              <div className="relative z-10 flex h-full flex-col justify-between">
                <div>
                  <p className="mb-4 text-xs uppercase tracking-[0.35em] text-cyan-300/60">
                    {item.category}
                  </p>

                  <h3 className="text-3xl font-semibold tracking-tight">
                    {item.title}
                  </h3>

                  <p className="mt-5 max-w-md text-sm leading-7 text-white/50">
                    {item.description}
                  </p>
                </div>

                <div className="mt-10 grid grid-cols-3 gap-3">
                  <div className="h-24 rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/[0.02]" />
                  <div className="h-24 rounded-2xl border border-white/10 bg-gradient-to-br from-cyan-300/20 to-white/[0.02]" />
                  <div className="h-24 rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-cyan-300/10" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}