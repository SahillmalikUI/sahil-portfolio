"use client";

import { motion } from "motion/react";

const skillGroups = [
  {
    title: "Frontend & Mobile",
    skills: ["Flutter", "Dart", "Next.js", "TypeScript", "Tailwind CSS"],
  },
  {
    title: "UI/UX & Visual Design",
    skills: ["Figma", "Design Systems", "Wireframing", "Prototyping", "Branding"],
  },
  {
    title: "Backend",
    skills: ["Node.js", "Express.js", "REST APIs", "JWT Auth", "MongoDB", "PostgreSQL"],
  },
  {
    title: "HMI / Embedded UI",
    skills: ["Crank Storyboard", "Lua", "Embedded UI", "HMI Systems", "Real-time UI"],
  },
];

export default function StackExperience() {
  return (
    <section id="stack" className="relative px-6 py-28">
      <div className="mx-auto grid max-w-7xl gap-16 lg:grid-cols-[1fr_1fr]">
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8 }}
        >
          <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
            Stack
          </p>

          <h2 className="text-4xl font-semibold tracking-tight md:text-6xl">
            Tools I use to design, build, and ship.
          </h2>

          <p className="mt-6 max-w-xl text-base leading-8 text-white/50">
            I combine development and design tools to create interfaces that are
            clean, functional, responsive, and ready for real-world usage.
          </p>

          <div className="mt-10 grid gap-4">
            {skillGroups.map((group, index) => (
              <motion.div
                key={group.title}
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-120px" }}
                transition={{ duration: 0.7, delay: index * 0.1 }}
                className="rounded-[1.5rem] border border-white/10 bg-white/[0.03] p-5"
              >
                <h3 className="mb-4 text-lg font-semibold">{group.title}</h3>

                <div className="flex flex-wrap gap-2">
                  {group.skills.map((skill) => (
                    <span
                      key={skill}
                      className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/55"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8 }}
          className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-7 md:p-9"
        >
          <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
            Experience
          </p>

          <h2 className="text-3xl font-semibold tracking-tight md:text-5xl">
            Building products where design and engineering meet.
          </h2>

          <div className="mt-10 border-l border-white/10 pl-6">
            <div className="relative">
              <div className="absolute -left-[31px] top-1 h-3 w-3 rounded-full bg-cyan-300" />

              <p className="text-sm uppercase tracking-[0.25em] text-white/35">
                Jan 2025 — Present
              </p>

              <h3 className="mt-3 text-2xl font-semibold">
                Flutter & Full Stack Developer
              </h3>

              <p className="mt-2 text-sm text-cyan-300/70">BluAi • India</p>

              <p className="mt-5 text-base leading-8 text-white/55">
                Working on frontend UI design and implementation for smart
                healthcare interfaces, real-time dashboards, embedded-style UI,
                and backend/API integration support.
              </p>

              <div className="mt-6 grid gap-3">
                {[
                  "Built real-time vitals interface screens and dashboard flows",
                  "Worked with Figma, Crank Storyboard, Lua, Flutter Embedded, and APIs",
                  "Implemented UI for ECG-style visualization and health data display",
                  "Collaborated around product, backend, and interface requirements",
                ].map((item) => (
                  <div
                    key={item}
                    className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-white/55"
                  >
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-10 rounded-[1.5rem] border border-cyan-300/20 bg-cyan-300/10 p-5">
            <p className="text-sm leading-7 text-cyan-50/75">
              Currently focusing on Next.js, TypeScript, advanced backend
              development, creative frontend interactions, and building a
              stronger designer-developer portfolio.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}