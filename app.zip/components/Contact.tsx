"use client";

import { motion } from "motion/react";

export default function Contact() {
  return (
    <section id="contact" className="relative overflow-hidden px-6 py-28">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,rgba(56,189,248,0.16),transparent_35%)]" />

      <div className="relative z-10 mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8 }}
          className="rounded-[2.5rem] border border-white/10 bg-white/[0.04] p-8 text-center backdrop-blur-xl md:p-16"
        >
          <p className="mb-5 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
            Contact
          </p>

          <h2 className="mx-auto max-w-4xl text-4xl font-semibold tracking-tight md:text-7xl">
            Let’s build something sharp, smooth, and premium.
          </h2>

          <p className="mx-auto mt-7 max-w-2xl text-base leading-8 text-white/55 md:text-lg">
            Open to developer roles, frontend projects, Flutter apps, UI/UX work,
            full-stack products, and creative web experiences.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a
              href="mailto:mohdsahilali6051@gmail.com"
              className="rounded-full bg-white px-8 py-3 text-sm font-semibold text-black transition hover:scale-105"
            >
              Email Me
            </a>

            <a
              href="https://www.linkedin.com/in/mohammed-sahil-ali-4a53a4216"
              target="_blank"
              className="rounded-full border border-white/15 px-8 py-3 text-sm font-semibold text-white/75 transition hover:border-white/40 hover:text-white"
            >
              LinkedIn
            </a>

            <a
              href="https://github.com/SahillmalikUI"
              target="_blank"
              className="rounded-full border border-white/15 px-8 py-3 text-sm font-semibold text-white/75 transition hover:border-white/40 hover:text-white"
            >
              GitHub
            </a>
          </div>
        </motion.div>

        <footer className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 text-sm text-white/35 md:flex-row">
          <p>© 2026 Sahil Malik. Built with Next.js, TypeScript, Tailwind, Motion & GSAP.</p>
          <p>Developer • Designer • Builder</p>
        </footer>
      </div>
    </section>
  );
}