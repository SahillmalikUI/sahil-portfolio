"use client";

const navItems = ["Work", "Design Lab", "Stack", "About", "Contact"];

export default function Navbar() {
  return (
    <header className="fixed left-0 top-0 z-50 w-full px-6 py-5">
      <nav className="mx-auto flex max-w-7xl items-center justify-between rounded-full border border-white/10 bg-white/5 px-5 py-3 backdrop-blur-xl">
        <a href="#" className="text-sm font-semibold tracking-wide text-white">
          Sahil<span className="text-white/40">.dev</span>
        </a>

        <div className="hidden items-center gap-7 md:flex">
          {navItems.map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(" ", "-")}`}
              className="text-sm text-white/55 transition hover:text-white"
            >
              {item}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-4 text-xs font-medium uppercase tracking-wider">
          <a
            href="https://github.com/SahillmalikUI"
            target="_blank"
            className="text-white/60 transition hover:text-white"
          >
            GH
          </a>

          <a
            href="https://www.linkedin.com/in/mohammed-sahil-ali-4a53a4216"
            target="_blank"
            className="text-white/60 transition hover:text-white"
          >
            IN
          </a>

          <a
            href="mailto:mohdsahilali6051@gmail.com"
            className="text-white/60 transition hover:text-white"
          >
            Mail
          </a>
        </div>
      </nav>
    </header>
  );
}