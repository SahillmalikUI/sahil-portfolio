"use client";

import { motion } from "motion/react";

const projects = [
  {
    number: "01",
    title: "BluAi Vitals Chair UI",
    type: "Healthcare Interface / HMI UI",
    description:
      "Frontend UI design and implementation for a real-time healthcare interface with vitals screens, ECG-style visualization, dashboard flows, and API/backend integration support.",
    stack: ["Figma", "Crank Storyboard", "Lua", "Flutter Embedded"],
    link: "https://bluai.ai/products/vitals-chair/",
    status: "Commercial Product",
  },
  {
    number: "02",
    title: "VitalsLog",
    type: "Full Stack Health App",
    description:
      "A full-stack health tracking app with Flutter frontend, backend APIs, authentication, database integration, and health status classification.",
    stack: ["Flutter", "Node.js", "Express", "MongoDB", "JWT"],
    link: "https://github.com/SahillmalikUI/vitalslog",
    status: "Full Stack Build",
  },
  {
    number: "03",
    title: "Design Lab",
    type: "UI/UX Experiments",
    description:
      "A collection of interface experiments, dashboards, landing pages, product visuals, and design explorations created using Figma and frontend tools.",
    stack: ["Figma", "UI Design", "Frontend", "Branding"],
    link: "#design-lab",
    status: "Visual Experiments",
  },
];

export default function SelectedWork() {
  return (
    <section id="work" className="relative px-6 py-28">
      <div className="mx-auto max-w-7xl">
        <div className="mb-16 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
              Selected Work
            </p>

            <h2 className="max-w-3xl text-4xl font-semibold tracking-tight md:text-6xl">
              Work that shows taste, logic, and execution.
            </h2>
          </div>

          <p className="max-w-md text-sm leading-7 text-white/50">
            A curated mix of product interfaces, full-stack builds, real-time
            dashboards, and design explorations.
          </p>
        </div>

        <div className="grid gap-6">
          {projects.map((project, index) => (
            <motion.a
              key={project.title}
              href={project.link}
              target={project.link.startsWith("http") ? "_blank" : undefined}
              initial={{ opacity: 0, y: 45 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-120px" }}
              transition={{ duration: 0.75, delay: index * 0.12 }}
              className="group relative overflow-hidden rounded-[2.3rem] border border-white/10 bg-white/[0.03] p-6 transition duration-500 hover:-translate-y-1 hover:border-cyan-300/40 hover:bg-white/[0.06] md:p-8"
            >
              <div className="absolute inset-0 opacity-0 transition duration-500 group-hover:opacity-100">
                <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-cyan-400/20 blur-[100px]" />
                <div className="absolute -bottom-20 left-1/3 h-72 w-72 rounded-full bg-blue-500/10 blur-[100px]" />
              </div>

              <div className="relative z-10 grid gap-8 lg:grid-cols-[0.25fr_0.9fr_1.1fr_0.35fr] lg:items-center">
                <div>
                  <p className="text-sm text-white/35">{project.number}</p>
                </div>

                <div>
                  <p className="mb-3 text-xs uppercase tracking-[0.3em] text-cyan-300/60">
                    {project.type}
                  </p>

                  <h3 className="text-3xl font-semibold tracking-tight md:text-5xl">
                    {project.title}
                  </h3>

                  <div className="mt-5 inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs text-cyan-100/75">
                    {project.status}
                  </div>
                </div>

                <div>
                  <p className="text-base leading-8 text-white/55">
                    {project.description}
                  </p>

                  <div className="mt-6 flex flex-wrap gap-2">
                    {project.stack.map((item) => (
                      <span
                        key={item}
                        className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/55"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex justify-start lg:justify-end">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-xl text-white/60 transition group-hover:border-cyan-300/40 group-hover:text-cyan-200">
                    ↗
                  </div>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}