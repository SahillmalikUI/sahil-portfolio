"use client";

import { motion } from "motion/react";

const highlights = [
  "Frontend UI design & implementation",
  "Real-time vitals interface screens",
  "ECG-style visualization",
  "Dashboard flows & patient UI",
  "API/backend integration support",
  "Commercial healthcare product UI",
];

export default function VitalsCaseStudy() {
  return (
    <section className="relative overflow-hidden px-6 py-28">
      <div className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-400/10 blur-[140px]" />

      <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-center">
        <motion.div
          initial={{ opacity: 0, x: -45 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8 }}
          className="relative z-10"
        >
          <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
            Featured Case Study
          </p>

          <h2 className="text-4xl font-semibold tracking-tight md:text-6xl">
            BluAi Vitals Chair UI
          </h2>

          <p className="mt-6 max-w-xl text-base leading-8 text-white/55">
            Frontend UI design and implementation for a real-time healthcare
            interface. I worked on vitals screens, dashboard flows,
            ECG-style visualization, and integration support for a commercial
            healthcare product.
          </p>

          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            {highlights.map((item) => (
              <div
                key={item}
                className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white/60"
              >
                {item}
              </div>
            ))}
          </div>

          <div className="mt-9 flex flex-col gap-4 sm:flex-row">
            <a
              href="https://bluai.ai/products/vitals-chair/"
              target="_blank"
              className="rounded-full bg-cyan-300 px-7 py-3 text-sm font-semibold text-black transition hover:scale-105"
            >
              View Live Product
            </a>

            <a
              href="#contact"
              className="rounded-full border border-white/15 px-7 py-3 text-sm font-semibold text-white/75 transition hover:border-white/40 hover:text-white"
            >
              Discuss Project
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 45, rotate: 2 }}
          whileInView={{ opacity: 1, x: 0, rotate: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.9 }}
          className="relative z-10"
        >
          <div className="relative rounded-[2rem] border border-white/10 bg-white/[0.04] p-4 shadow-2xl shadow-cyan-950/30 backdrop-blur-xl">
            <div className="rounded-[1.5rem] border border-white/10 bg-[#070707] p-5">
              <div className="mb-5 flex items-center justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.3em] text-cyan-300/60">
                    Patient Vitals
                  </p>
                  <h3 className="mt-2 text-2xl font-semibold">
                    Live Health Dashboard
                  </h3>
                </div>

                <div className="rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs text-cyan-200">
                  LIVE
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {["ECG", "SpO2", "Heart Rate", "Blood Pressure"].map(
                  (item, index) => (
                    <div
                      key={item}
                      className="rounded-2xl border border-white/10 bg-white/[0.03] p-4"
                    >
                      <p className="text-xs uppercase tracking-[0.25em] text-white/35">
                        {item}
                      </p>

                      <div className="mt-5 h-16 overflow-hidden rounded-xl bg-black/40">
                        <motion.div
                          className="h-full w-[200%] bg-[linear-gradient(90deg,transparent,rgba(103,232,249,0.75),transparent)]"
                          animate={{ x: ["-50%", "0%"] }}
                          transition={{
                            duration: 2 + index * 0.4,
                            repeat: Infinity,
                            ease: "linear",
                          }}
                        />
                      </div>
                    </div>
                  )
                )}
              </div>

              <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <p className="text-xs uppercase tracking-[0.25em] text-white/35">
                  Interface Flow
                </p>

                <div className="mt-4 flex flex-wrap gap-2">
                  {["Patient", "Vitals", "AI Assist", "Report", "Doctor"].map(
                    (item) => (
                      <span
                        key={item}
                        className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/55"
                      >
                        {item}
                      </span>
                    )
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}