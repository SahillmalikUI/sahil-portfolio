"use client";

import { motion } from "motion/react";

export default function About() {
  return (
    <section id="about" className="relative px-6 py-28">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8 }}
        >
          <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
            About Me
          </p>

          <h2 className="text-4xl font-semibold tracking-tight md:text-6xl">
            Developer by logic. Designer by instinct.
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-120px" }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-7 md:p-10"
        >
          <p className="text-lg leading-9 text-white/60">
            I’m Sahil, a developer-designer focused on building clean,
            interactive, and premium digital experiences. I work across Flutter,
            frontend development, full-stack apps, UI/UX design, and real-time
            dashboard-style interfaces.
          </p>

          <p className="mt-6 text-lg leading-9 text-white/60">
            My strength is combining design taste with technical execution. I
            enjoy turning ideas into polished products — from Figma layouts to
            working interfaces, animations, APIs, and responsive experiences.
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {["Developer", "Designer", "Builder"].map((item) => (
              <div
                key={item}
                className="rounded-2xl border border-white/10 bg-black/20 p-4 text-center text-sm text-white/60"
              >
                {item}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}