"use client";

import { motion } from "motion/react";

const floatingCards = [
  {
    title: "UI/UX",
    value: "Figma",
  },
  {
    title: "Frontend",
    value: "Next.js",
  },
  {
    title: "Mobile",
    value: "Flutter",
  },
  {
    title: "Backend",
    value: "Node.js",
  },
];

export default function Hero() {
  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden px-6 pt-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(56,189,248,0.16),transparent_35%)]" />

      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:70px_70px] opacity-20" />

      <motion.div
        className="absolute left-1/2 top-1/2 h-[420px] w-[420px] rounded-full bg-cyan-400/20 blur-[120px]"
        animate={{
          x: [-220, 180, -220],
          y: [-120, 120, -120],
          scale: [1, 1.25, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-14 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="mb-6 text-sm uppercase tracking-[0.5em] text-cyan-300/70"
          >
            Developer • Designer • Builder
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 35, filter: "blur(10px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 1, delay: 0.15 }}
            className="text-5xl font-semibold tracking-tight md:text-7xl xl:text-8xl"
          >
            I design and build digital products that feel premium.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 35 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.35 }}
            className="mt-7 max-w-2xl text-base leading-8 text-white/60 md:text-xl"
          >
            I’m Sahil, a Flutter and Full Stack Developer with a strong eye for
            UI/UX. I build mobile apps, web experiences, dashboards, and
            real-time interfaces using Flutter, Figma, Node.js, and modern
            frontend tools.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 35 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.55 }}
            className="mt-10 flex flex-col gap-4 sm:flex-row"
          >
            <a
              href="#work"
              className="rounded-full bg-white px-7 py-3 text-center text-sm font-semibold text-black transition hover:scale-105"
            >
              View My Work
            </a>

            <a
              href="/resume.pdf"
              className="rounded-full border border-white/15 px-7 py-3 text-center text-sm font-semibold text-white/80 transition hover:border-white/40 hover:text-white"
            >
              Download Resume
            </a>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92, rotate: 3 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="relative hidden lg:block"
        >
          <div className="absolute -inset-10 rounded-full bg-cyan-300/10 blur-[90px]" />

          <div className="relative rounded-[2.5rem] border border-white/10 bg-white/[0.05] p-4 shadow-2xl shadow-cyan-950/40 backdrop-blur-xl">
            <div className="rounded-[2rem] border border-white/10 bg-[#080808] p-5">
              <div className="mb-5 flex items-center justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.35em] text-cyan-300/60">
                    Portfolio System
                  </p>
                  <h3 className="mt-2 text-2xl font-semibold">
                    Build Mode Active
                  </h3>
                </div>

                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="rounded-full bg-cyan-300 px-3 py-1 text-xs font-semibold text-black"
                >
                  LIVE
                </motion.div>
              </div>

              <div className="grid gap-3">
                {floatingCards.map((card, index) => (
                  <motion.div
                    key={card.title}
                    animate={{ y: [0, -8, 0] }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      delay: index * 0.25,
                      ease: "easeInOut",
                    }}
                    className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.04] p-4"
                  >
                    <div>
                      <p className="text-xs uppercase tracking-[0.3em] text-white/35">
                        {card.title}
                      </p>
                      <p className="mt-2 text-lg font-semibold">{card.value}</p>
                    </div>

                    <div className="h-10 w-10 rounded-full border border-cyan-300/20 bg-cyan-300/10" />
                  </motion.div>
                ))}
              </div>

              <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-xs uppercase tracking-[0.25em] text-white/35">
                    Visual Quality
                  </p>
                  <p className="text-xs text-cyan-300">Premium</p>
                </div>

                <div className="h-2 overflow-hidden rounded-full bg-white/10">
                  <motion.div
                    className="h-full rounded-full bg-cyan-300"
                    initial={{ width: "0%" }}
                    animate={{ width: "92%" }}
                    transition={{ duration: 1.2, delay: 1 }}
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}