"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

const showcaseItems = [
  {
    label: "01 / Product UI",
    title: "Real-time dashboard systems",
    description:
      "Interfaces built for live data, clean visibility, and smooth user experience.",
  },
  {
    label: "02 / Full Stack",
    title: "Apps with frontend + backend",
    description:
      "Flutter apps, REST APIs, authentication, database integration, and real product flows.",
  },
  {
    label: "03 / Design",
    title: "Premium interface direction",
    description:
      "Figma layouts, design systems, visual hierarchy, typography, and modern product styling.",
  },
  {
    label: "04 / Creative Frontend",
    title: "Web experiences that feel alive",
    description:
      "Motion, GSAP, scroll effects, interactive cards, animated grids, and smooth transitions.",
  },
];

export default function HorizontalShowcase() {
  const sectionRef = useRef<HTMLElement | null>(null);
  const trackRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    const section = sectionRef.current;
    const track = trackRef.current;

    if (!section || !track) return;

    const ctx = gsap.context(() => {
      const distance = track.scrollWidth - window.innerWidth;

      gsap.to(track, {
        x: -distance,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => `+=${distance}`,
          scrub: 1,
          pin: true,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative overflow-hidden bg-[#050505]">
      <div className="flex h-screen items-center">
        <div ref={trackRef} className="flex w-max gap-6 px-6">
          <div className="flex w-[90vw] shrink-0 flex-col justify-center">
            <p className="mb-4 text-sm uppercase tracking-[0.4em] text-cyan-300/70">
              Creative Direction
            </p>

            <h2 className="max-w-4xl text-5xl font-semibold tracking-tight md:text-8xl">
              Not just a portfolio. A product experience.
            </h2>

            <p className="mt-7 max-w-2xl text-lg leading-8 text-white/50">
              This site is designed to show recruiters that I can think visually,
              build technically, and present work like a real product.
            </p>
          </div>

          {showcaseItems.map((item) => (
            <div
              key={item.title}
              className="relative flex h-[70vh] w-[78vw] shrink-0 flex-col justify-between overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/[0.04] p-8 md:w-[55vw] md:p-12"
            >
              <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-cyan-300/20 blur-[100px]" />

              <div className="relative z-10">
                <p className="text-sm uppercase tracking-[0.35em] text-cyan-300/60">
                  {item.label}
                </p>

                <h3 className="mt-6 max-w-xl text-4xl font-semibold tracking-tight md:text-6xl">
                  {item.title}
                </h3>

                <p className="mt-6 max-w-lg text-base leading-8 text-white/55">
                  {item.description}
                </p>
              </div>

              <div className="relative z-10 grid grid-cols-3 gap-4">
                <div className="h-28 rounded-3xl border border-white/10 bg-white/[0.04]" />
                <div className="h-28 rounded-3xl border border-cyan-300/20 bg-cyan-300/10" />
                <div className="h-28 rounded-3xl border border-white/10 bg-white/[0.04]" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}