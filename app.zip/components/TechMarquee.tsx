"use client";

import { motion } from "motion/react";

const techStack = [
  "Flutter",
  "Dart",
  "Figma",
  "Next.js",
  "TypeScript",
  "Tailwind CSS",
  "Motion",
  "GSAP",
  "Node.js",
  "Express.js",
  "REST APIs",
  "JWT Auth",
  "MongoDB",
  "PostgreSQL",
  "Crank Storyboard",
  "Lua",
  "Embedded UI",
  "HMI Systems",
];

export default function TechMarquee() {
  return (
    <section className="relative overflow-hidden border-y border-white/10 bg-white/[0.02] py-6">
      <div className="pointer-events-none absolute left-0 top-0 z-10 h-full w-32 bg-gradient-to-r from-[#050505] to-transparent" />
      <div className="pointer-events-none absolute right-0 top-0 z-10 h-full w-32 bg-gradient-to-l from-[#050505] to-transparent" />

      <motion.div
        className="flex w-max gap-4"
        animate={{ x: ["0%", "-50%"] }}
        transition={{
          duration: 28,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        {[...techStack, ...techStack].map((item, index) => (
          <span
            key={`${item}-${index}`}
            className="rounded-full border border-white/10 bg-white/[0.03] px-5 py-2 text-sm text-white/55"
          >
            {item}
          </span>
        ))}
      </motion.div>
    </section>
  );
}