import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import TechMarquee from "../components/TechMarquee";
import SelectedWork from "../components/SelectedWork";
import HorizontalShowcase from "../components/HorizontalShowcase";
import VitalsCaseStudy from "../components/VitalsCaseStudy";
import DesignLab from "../components/DesignLab";
import StackExperience from "../components/StackExperience";
import Contact from "../components/Contact";
import ScrollProgress from "../components/ScrollProgress";
import About from "../components/About";
import CredibilityStrip from "../components/CredibilityStrip";
import Process from "../components/Process";

export default function Home() {
  return (
    <main className="min-h-screen overflow-hidden bg-[#050505] text-white">
      <ScrollProgress />
      <Navbar />
      <Hero />
      <TechMarquee />
      <CredibilityStrip />
      <SelectedWork />
      <HorizontalShowcase />
      <VitalsCaseStudy />
      <DesignLab />
      <About />
      <Process />
      <StackExperience />
      <Contact />
    </main>
  );
}